<?php
/**
 * Created by PhpStorm.
 * User: yuhaoliu
 * Date: 19/10/2016
 * Time: 9:10 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{

}