<?php $__env->startSection('content'); ?>
    <h1>Write a New Article</h1>

    <hr/>

    <?php echo Form::open(); ?>

    <div class="form-group">
        <p>dwdawwadaw</p>
        <?php echo Form::label('name', 'Name:'); ?>

        <?php echo Form::text('cus_name', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('phone', 'Phone:'); ?>

        <?php echo Form::text('cus_phone', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('email', 'Email:'); ?>

        <?php echo Form::text('cus_email', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('hand', 'Handside:'); ?>

        <?php echo Form::select('cus_hand', array('L' => 'Left Hand' ,'R' => 'Right Hand')); ?>

    </div>

    <div class="form-group">
        <?php echo Form::submit('Booking', ['class' => 'btn btn-primary form-control']); ?>

    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>